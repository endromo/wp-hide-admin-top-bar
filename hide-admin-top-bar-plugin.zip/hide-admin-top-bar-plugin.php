<?php
 
/**
 * Plugin Name:       Hide Admin Top Bar
 * Description:       This is a plugin to hide the Admin Bar at the top of the page.
 * Version:           1.0.0
 * Author: 	      Endro	
 */
 
add_filter( 'show_admin_bar', '__return_false' );
